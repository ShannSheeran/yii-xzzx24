define(["jQuery",'app/common/Request', 'app/common/Ui', 'artDialog'], function (require, exports, module) {
    var $ = require("jQuery");
    var Request = require("app/common/Request");
    var Ui = require("app/common/Ui");
    //加载弹窗插件
    var dialog = require('artDialog');
    
    var oFankui = { 
            bindEvent:function(){ 
                //提交
                $('.J-fankui').click(function(){ 
                    var content = $('.textarea_fankui').val();
                    if(content.length == 0){
                        return;
                    }
                    Request.ajax({ 
                        url: _aConfig.fankuiUrl,
                        data:{content:content},
                        success:function(oData){
                            if(oData.status ==1){ 
                               var r = dialog({
                                content: '反馈成功！！'
                            });
                            r.show();
                            setTimeout(function () {
                                r.close().remove();
                                history.go(-1);
                            }, 1500);
                            }
                            if(oData.status ==0){ 
                               var r = dialog({
                                content: '评论失败！！'
                            });
                            r.show();
                            setTimeout(function () {
                                r.close().remove();
                                history.go(-1);
                            }, 1500);

                            }
                        }
                    });
                
                });
                
            },
            config: function (aOptions) {
            for (var key in aOptions) {
                if (_aConfig[key] !== undefined) {
                    _aConfig[key] = aOptions[key];
                }
            }
            }
    
    };
    var _aConfig = {
        fankuiUrl: ''
    };
   module.exports = oFankui;
});