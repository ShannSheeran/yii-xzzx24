define(["jQuery","external/dropload/dropload.min"], function (require, exports, module) {
    var $ = window.$ || require("jQuery");
    require("external/dropload/dropload.min");
    module.exports = function ($loadDom,oOption) {
        if(oOption == undefined){
            oOption = {};
        }
        if(oOption.domDowm == undefined){
            oOption.domDowm = {
                domClass: 'dropload-down',
                domRefresh: '<div class="dropload-refresh">↑上拉加载更多</div>',
                domLoad: '<div class="dropload-load"><span class="loading"></span>加载中...</div>',
                domNoData: '<div class="dropload-noData">暂无数据</div>'
            }
        }
        if(oOption.scrollArea == undefined){
            oOption.scrollArea = window;
        }
        if(oOption.distance == undefined){
            oOption.distance = 30;
        }
        if(oOption.loadDownFn == undefined){
            oOption.loadDownFn = function(oLoadMore){
                
            };
        }
        $(function(){
            $loadDom.dropload(oOption);
        });
        
    }
});

