define('app/common/Request',['jQuery'],function(require, exports, module){
	var $ =  require("jQuery");
	var Request = {};
	Request.getFormJson = function (aData) {
		var oData = {};
		$.each(aData, function () {
			if (oData[this.name] !== undefined) {
				if (!oData[this.name].push) {
					oData[this.name] = [oData[this.name]];
				}
				oData[this.name].push(this.value || '');
			} else {
				oData[this.name] = this.value || '';
			}
		});
		return oData;
	};

	Request.ajax = function (option) {
		(option.url == undefined) && $.error('url is null');
		(option.type == undefined) && (option.type = 'post');
		(option.dataType == undefined) && (option.dataType = 'json');
		(option.error == undefined) && (option.error = function () {
			console.log('网络出错了。。');
		});
		if (option.data != undefined && option.data.referrerUrl == undefined) {
			option.data.referrer_url = document.referrer;
		}
		var successFunc = function (result) {
			if (result.status != undefined) {
				alert(result.info);
			}

		};
		if (option.success !== undefined) {
			successFunc = option.success;
		}
		option.success = function (aRsult) {
			successFunc(aRsult);
		}                
		try {
			$.ajax(option);
		} catch (e) {
			$.error('send data is happened error');
		}
	}
        
    Request.ajaxSend = function ($formDom, ajaxOption, $clickDom) {
        if ($formDom.attr('url') == undefined && ajaxOption.url == undefined) {
            $.error('url is not defined');
        }
        var aData = Request.getFormJson($formDom.serializeArray());
        for (var i in aData) {
            var $this = $formDom.find('input[name="' + i + '"]');
            if ($this.length == 0) {
                $this = $formDom.find('select[name="' + i + '"]');
            }
            if ($this.length == 0) {
                $this = $formDom.find('textarea[name="' + i + '"]');
            }
            if ($this.data('required')) {
                if ($this.val() == "") {
                    alert("该字段不能为空");
                    $this.focus();
                    return;
                }
            }
            var pattern = $this.data('pattern');
            if (pattern !== undefined && $this.val() != "") {
                if (!new RegExp(pattern).test($this.val())) {
                    if ($this.data('error_info') != undefined) {
                        alert($this.data('error_info'));
                    } else {
                        alert("请正确填写该字段");
                    }
                    $this.focus();
                    return;
                }
            }
        }
        Request.clearDataNullWorth(aData);

        if ($clickDom != undefined) {
            if (ajaxOption.beforeSend != undefined) {
                var beforeSend = ajaxOption.beforeSend;
                ajaxOption.beforeSend = function () {
                    if ($clickDom.data('status') != undefined && !$clickDom.data('status')) {
                        return false;
                    }
                    $clickDom.html('数据提交中..');
                    $clickDom.data('status', false);
                    beforeSend();
                }
            }
            if (ajaxOption.success != undefined) {
                var success = ajaxOption.success;
                ajaxOption.success = function (aResult) {
                    $clickDom.html('提交完成');
                    $clickDom.data('status', true);
                    success(aResult);
                }
            }

        }
        ajaxOption.data = aData;
        Request.ajax(ajaxOption);
    }
        
    Request.ajaxSend1 = function ($formDom, ajaxOption) {
		if ($formDom.attr('url') == undefined && ajaxOption.url == undefined) {
			$.error('url is not defined');
		}
		var aData = Request.getFormJson($formDom.serializeArray());
		for (var i in aData) {
			var $this = $formDom.find('input[name="' + i + '"]');
			if ($this.length == 0) {
				$this = $formDom.find('select[name="' + i + '"]');
			}
			if ($this.length == 0) {
				$this = $formDom.find('textarea[name="' + i + '"]');
			}
			if ($this.data('required')) {
				if ($this.val() == "") {
					alert("该字段不能为空");
					$this.focus();
					return;
				}
			}
			var pattern = $this.data('pattern');
			if (pattern !== undefined && $this.val() != "") {
				if (!new RegExp(pattern).test($this.val())) {
					if ($this.data('error_info') != undefined) {
						alert($this.data('error_info'));
					} else {
						alert("请正确填写该字段");
					}
					$this.focus();
					return;
				}
			}
		}
		Request.clearDataNullWorth(aData);
		ajaxOption.data = aData;
		Request.ajax(ajaxOption);
	}
	Request.clearDataNullWorth = function (aData) {
		for (var i in aData) {
			if (aData[i] == '') {
				delete aData[i];
			}
		}
	},
	Request.inArray = function (value, array, isStrict) {
		for (var i in array) {
			if (array[i] == value && !isStrict) {
				return true;
			} else if (array[i] === value && isStrict) {
				return true;
			}
		}
		return false;
	}
        var self = Request;
        console.log(Request);
	//这里放jQuery源代码
	module.exports = Request;
});