define('app/common/Tips',["jQuery","external/layer_mobile/layer"], function (require, exports, module) {
    var $ = window.$ || require("jQuery");
    var oLy = require("external/layer_mobile/layer");
    
    module.exports = {
        /**
         * 
         * @param {type} title
         * @param {type} content
         * @param {type} second
         * @param {type} cb
         * @param {type} oPrameter
         * 
         * oTips.showTips('title','cotent',5,function(o){
            console.log(o);
        },{id:88888});
         */
        showTips: function (content, second, cb, oPrameter) {
            if (second == undefined) {
                second = 3;
            }
            if (oPrameter == undefined) {
                oPrameter = {};
            }
            if (cb == undefined) {
                cb = function () {};
            }
            var index = oLy.open({
                shadeClose: false,
                content: content,
                skin: 'msg',
            });
            setTimeout(function () {
                oLy.close(index);
                cb(oPrameter);
            }, second * 1000);
        },
        
        /**
         * 消息框弹框
         * @param {type} content
         * @param {type} btn
         * @param {type} cb
         */
        messageTips:function(content,btn,cb){ 
            if(content == undefined){ 
                content = 'please try again';
            }
            if (cb == undefined) {
                cb = function () {};
            }
            oLy.open({
                content: content,
                btn: btn
             });
        },
        
        /**
         * 询问框
         * @param {type} content
         * @param {type} oConfig
         * oTips.askIips('你最好小心点',{
            rBtnTitle:'确定1',
            lBtnTitle:'取消3',
            rFn:function(dd){
                console.log(dd);
            },
            lFn:function(cc){
                console.log(cc);
            },
            rPramater:{id:999},
            lPramater:{id:100},
           });
         * 
         */
        askIips: function (content,oConfig) {
            if(oConfig == undefined){
                oConfig = {};
            }
            var oDefault ={
                rBtnTitle:'确定',
                lBtnTitle:'取消',
                rFn:function(){                    
                },
                lFn:function(){                    
                },
                rPramater:null,
                lPramater:null,
            }            
            var oNowConfig = $.extend({},oDefault,oConfig);            
            oLy.open({
                content: content,
                shadeClose: false,
                btn: [oNowConfig.rBtnTitle, oNowConfig.lBtnTitle],
                yes: function () {
                    alert(1);
                    oNowConfig.lFn(oNowConfig.lPramater);
                },
                no:function(){
                    alert(0);
                    oNowConfig.rFn(oNowConfig.rPramater);
                }
            });
        },
        loading:function(type,content){
            if(type == undefined){
                type = 2;
            }
            if(content == undefined){
                content = '加载中';
            }
            //loading带文字
            var index = oLy.open({
                shadeClose: false,
                type: type,
                content: content
            });
            return index;
        },
        closeLoading:function(index){
            oLy.close(index);
        },
        xxx:function(){
              var oDefaultConfig = {
                content: content,
                skin: title,
                time: 2 //2秒后自动关闭
           };
           var aNowConfig = {
                content: content,
                skin: title,
                time: 2 //2秒后自动关闭
           };
            //提示
            oLy.open($.extend({},oDefaultConfig,aNowConfig));
        }
       
        
    }
});

