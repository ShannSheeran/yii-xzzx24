define(["jQuery", 'external/layer/layer'], function (require, exports, module) {
	var $ = window.$ || require("jQuery");
	var layer = require('external/layer/layer');

	var tg = [];

	tg.load = function (url, callback, type, data) {
		if (typeof type == "undefined") {
			type = "get";
		}
		if (typeof data == "undefined") {
			data = {};
		}
		func_ajax(url, callback, type, data, "加载中，请稍等...");
	}

	tg.save = function (url, callback, type, data) {
		if (typeof type == "undefined") {
			type = "get";
		}
		if (typeof data == "undefined") {
			data = {};
		}
		func_ajax(url, callback, type, data, "处理中，请稍等...");
	}

	tg.msg = function (msg) {
		var lay = layer.open({
			shade: false,
			shadeClose: true,
			style: 'border:none;background-color:#333;color:#fff;text-align:center;',
			content: msg
		});
		setTimeout("func_close()", 3000);
	}

	tg.confirm = function () {

	}

	function func_ajax(url, callback, type, data, msg) {
		var lay;
		$.ajax({
			url: url,
			type: type,
			data: data,
			dataType: "json",
			beforeSend: function (XMLHttpRequest) {
				lay = layer.open({ type: 2, shade: false, shadeClose: false, content: msg });
				console.log(layer.open);
				
			},
			success: function (data, textStatus) {
				if (typeof callback == "function") {
					callback(data);
				}
				layer.close(lay);
			},
			error: function (XMLHttpRequest, textStatus, errorThrown) {
				tg.msg("网络异常，请稍后重试");
				layer.close(lay);
			}
		});
	}

	function func_close() {
		layer.closeAll();
	}

	module.exports = tg;
});