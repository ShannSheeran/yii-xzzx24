define(["jQuery","artDialog", 'external/spinner/jquery.Spinner', 'app/common/Request', 'app/common/Ui', 'app/common/load_more','external/touchSlider/TouchSlide.1.1'], function (require, exports, module) {
    var $ = require("jQuery");
    require("external/spinner/jquery.Spinner");
    var Request = require("app/common/Request");
    var Ui = require("app/common/Ui");
    var dialog = require('artDialog');

    var loadMore = require('app/common/load_more');
     var oTouchSlide = require('external/touchSlider/TouchSlide.1.1');

    //去请求分类信息数据的“类”
    var oDetail = {
        getDetailList: function () {
            Request.ajax({
                type: 'get',
                url: _aConfig.goodsDetailUrl,
                success: function (aData) {
                    if(aData.status == 0){                        
                         var r = dialog({
                            content: aData.msg
                        });
                        r.show();						
                        setTimeout(function () {
                            r.close().remove();
                            return history.go(-1);
                        }, 2000);
                    }else{
                        $('.J-detailParentDiv').show();
                        _oSlideList.appendSlideListHtml(aData.data.pics);
                        //填充喜欢按钮数据
                        if(aData.data.is_like == 1){ 
                            $('.J-like').addClass('current');
                        }
                        $('.J-like').data('goods_gid',aData.data.id);
                        $('.J-like').closest('b').find('span').html(aData.data.like_no);
                        _oDetailList.appendDetailListHtml(aData.data);
                        _oDetailDesc.appendDetailDescHtml(aData.data);
                        self.initGoodsList();
                        
                        _domGoodsDetail.find(".spinner").spinner();
                        //给加减插件加默认值
                        $('.a_buy').click(function(){
                             var total=$('.amount').val();
                            window.location.href=_aConfig.confirmUrl+total;
                        });

                    }
                    
                }
            });
        },
        initGoodsList: function () {
            //处理加载更多
            loadMore(_$domLoadMore, {
                distance:50,
                domDown: {
                    domClass: 'dropload-down',
                    domRefresh: '<div class="dropload-refresh"><h4 style="padding: 20px 0; background-color: #eee;"><s></s>继续拖动，查看图文详情</h4></div>',
                    domLoad: '<div class="dropload-load"><span class="loading"></span>加载中...</div>',
                    domNoData: '<div class="dropload-noData">暂无数据</div>'
                },
                loadDownFn: function (oLoadMore) {
                    if(_$domDetailShowDom == null || _$domDetailShowDom == ''){
                         _$domLoadMore.remove();
                        return _$domGoodsPic.append('<div class="col-xs-12 div_tuodong"><h4><s></s>亲没有详情了哦！么么哒！</h4></div>');
                        
                    }                    
                    setTimeout(function(){
                        _$domGoodsPic.append(_$domDetailShowDom);
                        $('').appendTo(_$domGoodsPic.next());
                        
                        oLoadMore.noData();
                        _$domLoadMore.remove();
                         //为每一个img标签添加属性
                        $('.J-goodsPic p img').each(function(){ 
                            $(this).addClass('img-responsive');
                            $(this).attr('alt','Responsive image');
                        });
                    },500)
                   

                }
            });
        },
       
        //参数处理函数
        config: function (aOptions) {
            for (var key in aOptions) {
                if (_aConfig[key] !== undefined) {
                    _aConfig[key] = aOptions[key];
                }
            }

        }

    };
        //幻灯片列表处理“类”
    var _oSlideList = {
        buildSlideList: function (oDataList) {
            var aHtml = [];
            for (var i in oDataList) {
                var url = 'javascript:void(0);';
                aHtml.push('<li><a href="' + url + '">' + Ui.buildImage(_aConfig.thumbUrl + oDataList[i].attachment,undefined,{class:'img-responsive',alt:'Responsive image'}) + '</a></li>');
            }
            return aHtml.join('');
        },
        appendSlideListHtml: function (oData) {
            _$domSlide.append(_oSlideList.buildSlideList(oData));
            oTouchSlide({
                slideCell: "#leftTabBox",
                slideCell:"#focusDetailBanner",
                titCell: ".hd ul", //开启自动分页 autoPage:true ，此时设置 titCell 为导航元素包裹层
                mainCell: ".bd ul",
                effect: "leftLoop",
                autoPlay: true, //自动播放
                autoPage: true //自动分页 
            });
        }
    };
    //分类数据处理的"类"
    var _oDetailList = {
        //负责append
        appendDetailListHtml: function (oData) {
            _domGoodsDetail.append(_oDetailList.buildDetailList(oData));
        },
        //负责遍历数据
        buildDetailList: function (oDataList) {
            var flag = oDataList.flag;
            var fenxiaoyouhui = '';
            if(flag > 0 && oDataList.marketprice - oDataList.lowprice>0){ 
                fenxiaoyouhui ="<i style='background-color: #f5686d; color:#fff; padding:0 5px; border-radius:2px;'>会员优惠"+ (oDataList.marketprice - oDataList.lowprice) +"元</i>";
            }
            var cHtml = [];
            if(oDataList.country == 33){ 
                _aCountry = '韩国';
            }
            if(oDataList.country == 34){ 
                _aCountry = '日本';
            }
            if(oDataList.country == 35){ 
                _aCountry = '法国';
            }
            if(oDataList.country == 36){ 
                _aCountry = '美国';
            }
            if(oDataList.country == 37){ 
                _aCountry = '德国';
            }
            cHtml.push( '<h3 class="h3_price">\
                        <span style="color:#F50808">￥' + oDataList.marketprice + '</span>\
                            '+fenxiaoyouhui+'\
                        </h3>\
                        <p class="p_proname">\
                                <span>商品名称</span><b>' + oDataList.title + '</b>\
                        </p>\
                        <p class="p_proname">\
                                <a href="javascript:;"><span>' + oDataList.sales + '</span>人已购买</a>\
                        </p>');
            if(oDataList.pcate==251){
                cHtml.push( '<h4>\
                    <span style="float:left;display: inline-block;width: 25%;color:#898888;vertical-align: top;font-size: 14px; ">商品数量</span>\
                    <span class="increaseAndDecrease spinner J-goodsNums" style="float:left; margin-top:-5px;"></span>\
                </h4>\
                ');
            }
               
            return cHtml.join('');

        }
    };

    var _oDetailDesc = {
        //负责append
        appendDetailDescHtml: function (oData) {
            _$domGoodsDesc.append(_oDetailDesc.buildDetailDesc(oData));
            _$domDetailShowDom = oData.content;
        },
        buildDetailDesc: function (oDataList) {
            var aHtml = [];
            aHtml.push('<p><span>[产品描述]</span> ' + oDataList.description + '</p>');
            return aHtml.join('');
        },
    };
    var _domGoodsDetail = $('.J-goodsDetail');
    var _$domGoodsDesc = $('.J-goodsDesc');
    var _$domGoodsPic = $('.J-goodsPic');
    var _$domLoadMore = $('.J-loadMore');
    var _$domDetailShowDom = null;
   var _$domSlide = $('.J-slideList');

    var _aConfig = {
        thumbUrl: '',
        goodsDetailUrl: '',
        cateUrl: '',
        getGoodsListUrl: '',
        confirmUrl:''
    };
    var _aCountry = '';
    var self = oDetail;
    module.exports = oDetail;
});