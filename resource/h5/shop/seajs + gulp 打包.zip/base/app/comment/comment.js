define(["jQuery"],function(require,exports,module) {
	var $ =  require("jQuery");
	var Request = require("app/common/Request");
	var Ui = require("app/common/Ui");
	var testjs = require('app/index/test');


	//评论列表处理“类”
	var _oCommentList = {
		buildCommentList:function(oDataList){
			var aData = oDataList;
			if(aData.length == 0){
				if(_indexCommentLoadDataPage == 1){
					return '<div>数据为空</div>';
				}
				_indexCommentLoadDataPage = 'nodata';
					return '暂无数据';
			}

			var aHtml = [];
			for(var i in oDataList){
				aHtml.push('<tr>\
								<td>'+Ui.buildImage(_aConfig.thumbUrl+oDataList[i].thumb)+'</td>\
								<td>'+ oDataList[i].content+'</td>\
							</tr>');
			}
			return aHtml.join('');
		},

		appendCommentListHtml:function(aData){
			//append商品列表
			_$domComment.append(_oCommentList.buildCommentList(aData));

		}
	};
	var oComment = {

		//请求评论信息数据
		getCommentList:function(url){
			if(_indexCommentLoadDataPage == 'noData'){
				return;
			}
			Request.ajax({
				type:'get',
				url:url+'&page='+_indexCommentLoadDataPage,
				success:function(aData){
					console.log(aData);
					_oCommentList.appendCommentListHtml(aData);
					_indexCommentLoadDataPage++;
				}
			});
		},

		config : function(aOptions){
			for(var key in aOptions){
				if(_aConfig[key] !== undefined){
					_aConfig[key] = aOptions[key];
				}
			}
	}

};
	var _$domComment = $('.J-CommentList');
	var _indexCommentLoadDataPage = 1;
	var _indexCategoryList={168:'icon_foods',169:'icon_beauty',173:'icon_ladies'}
	var _aConfig = {
		thumbUrl:'',
		baseUrl:'',
	};
	var self = oComment;
	module.exports = oComment;
})

