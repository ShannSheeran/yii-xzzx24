define(["jQuery", 'http://res.wx.qq.com/open/js/jweixin-1.0.0.js'], function (require, exports, module) {
    var $ = require("jQuery");
    var wx = require('http://res.wx.qq.com/open/js/jweixin-1.0.0.js');

    module.exports = {
        bindWeichatEvent: function () {
            $('head').append($('<style>\
            .div_popup {\
                bottom: 0;\
                display: block;\
                left: 0;\
                position: fixed;\
                top: 0;\
                width: 100%;\
                z-index: 1111;\
            }\
            .div_mask{\
                background-color: #000;\
                height: 100%;\
                opacity: 0.5;\
                width: 100%;\
            }\
            .div_popup img{\
                width:60%;\
                position: relative;\
                z-index: 1200;\
            }</style>'));
            var wxData = {
                title: _aConfig.title,
                link: _aConfig.link,
                desc:  _aConfig.desc,
                imgUrl: _aConfig.imgUrl
            };

            wx.config({
                debug: false,
                appId: _aConfig.appId,
                timestamp: _aConfig.timestamp,
                nonceStr: _aConfig.nonceStr,
                signature: _aConfig.signature,
                jsApiList: [
                    'checkJsApi',
                    'onMenuShareTimeline',
                    'onMenuShareAppMessage',
                    'onMenuShareQQ',
                    'onMenuShareWeibo',
                    'onMenuShareQZone'
                ]
            });
            wx.ready(function () {
                //朋友圈
                wx.onMenuShareTimeline({
                    title: wxData.title,
                    link: wxData.link,
                    desc: wxData.desc,
                    imgUrl: wxData.imgUrl,
                    success: function () {
                        success();
                    }
                });
                //分享给朋友
                wx.onMenuShareAppMessage({
                    title: wxData.title,
                    link: wxData.link,
                    desc: wxData.desc,
                    imgUrl: wxData.imgUrl,
                    
                    success: function () {
                        success();
                    },
                    fail: function (res) {  
                        alert("分享失败，请重新尝试");  
                    }  
                });
                //QQ
                wx.onMenuShareQQ({
                    title: wxData.title,
                    link: wxData.link,
                    desc: wxData.desc,
                    imgUrl: wxData.imgUrl,
                    success: function () {
                        success();
                    }
                });
                //腾讯微博
                wx.onMenuShareWeibo({
                    title: wxData.title,
                    link: wxData.link,
                    desc: wxData.desc,
                    imgUrl: wxData.imgUrl,
                    success: function () {
                        success();
                    }
                });
                //QQ空间
                wx.onMenuShareQZone({
                    title: wxData.title,
                    link: wxData.link,
                    desc: wxData.desc,
                    imgUrl: wxData.imgUrl,
                    success: function () {
                        success();
                    }
                });
            });
            wx.error(function (res) {
                if ("{$signPackage['signature']}" != '')
                {
                    if ('{$checkjsweixin}' == '1')
                    {
                        if (res.errMsg = 'config:invalid signature')
                        {
                            //alert("转发接口失效，请联系管理员");
                        }
                    }
                }
            });
        },
        //参数处理函数
        config: function (aOptions) {
            for (var key in aOptions) {
                if (_aConfig[key] !== undefined) {
                    _aConfig[key] = aOptions[key];
                }
            }
        }

    };
    function success() {
        var page = _aConfig.page;
        var user = _aConfig.user;
        var tid = _aConfig.tid;
        $.post(_aConfig.url, {"page": page, "from_user": user, "tid": tid}, function (data) {
        }, "json");
    }

    var _aConfig = {
        title: "",
        link: "",
        desc: "",
        imgUrl: "",
        appId: "",
        timestamp: "",
        nonceStr: "",
        signature: "",
        page: "",
        user: "",
        tid: "",
        url: ""
    };
    console.log('this is weixin test script');
});

