define("app/member/index",["jQuery", 'external/touchSlider/TouchSlide.1.1', 'app/common/Request', 'app/common/Ui', 'external/swiper/swiper.min', 'app/common/load_more', 'external/layer/layer', 'app/common/common'], function (require, exports, module) {

	var $ = require("jQuery");
	var tg = require("app/common/common");
	var Request = require("app/common/Request");
	var Ui = require("app/common/Ui");
	var oIndex = {
		load: function () {
                    Request.ajax({
                        url:_aConfig.memberUrl,
                        dataType:'jsonp',
                        success:function(data){
                            $("#realname").text(data.agent.realname);
                            if (data.agent.avatar != "") {
                                    $("#avatar").attr("src", data.agent.avatar);
                            }
                            if (data.agent.agent_title != "") {
                                    $("#agent_title").text(data.agent.agent_title);
                            }
                        }
                    });
//			tg.load(url, function (data) {
//				if (data.code == 1) {
//					$("#realname").text(data.agent.realname);
//					if (data.agent.avatar != "") {
//						$("#avatar").attr("src", data.agent.avatar);
//					}
//					if (data.agent.agent_title != "") {
//						$("#agent_title").text(data.agent.agent_title);
//					}
//				}
//			});
		},
                 config: function (aOptions) {
                    for (var key in aOptions) {
                        if (_aConfig[key] !== undefined) {
                            _aConfig[key] = aOptions[key];
                        }
                    }
                },
	}
        var _aConfig = {
        memberUrl: ''
    };
    var self = oIndex;
    module.exports = oIndex;
})

