define(['jQuery'], function (require, exports, module) {
    var $ = require('jQuery');
     var oNav = {
        navInit: function () {
            $(".J-footerNav a").eq(0).children('span').addClass('current');//初始化第一个渲染
            $(".J-footerNav a").click(function () {
                var spanEl = $('#div_footer a');//所有a标签模块
                var index = $(this).index();//当前位置
                for (var i = 0; i < spanEl.length; i++) {
                    if (index == i) {//遍历所有A标签==当前点击时
                        $("#div_footer a").eq(i).children('span').addClass('current');
                    } else {
                        $("#div_footer a").eq(i).children('span').removeClass('current');
                    }
                }
            });
            //高亮
            $(".J-footerNav a").each(function(){
                var $this = $(this);
                var href = $this.attr('href');
                if(_aConfig.current == 0){
                    return;
                }
                $this.find('span').removeClass('current');
                if(-1 != href.indexOf('do='+_aConfig.current)){
                    $this.find('span').addClass('current');
                }
            });
        },
        config: function (aOptions) {
            for (var key in aOptions) {
                if (_aConfig[key] !== undefined) {
                    _aConfig[key] = aOptions[key];
                }
            }
        }

    };
    var _aConfig ={
        current:0,
    };
    var self = oNav;
    module.exports = oNav;
});


