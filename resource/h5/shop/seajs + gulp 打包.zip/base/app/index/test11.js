define('app/index/test11',["jQuery",'app/common/Request','app/common/Tips'],function(require,exports,module) {
    var Request = require('app/common/Request');
    var Tips = require('app/common/Tips');
    return function(){
            Request.ajax({
            url:'',
            data:{},
            success:function(aData){
                console.log(aData);
            },error:function(x){
                console.log('this  is 么');
            }
        });
        Tips.showTips('this is test');
    }
});